=====================================================
⚡ FILE TRANSFER FAST — WINDOWS HOST APP
=====================================================

HOW TO RUN:
1. Double-click "FileTransferFast.exe" (the blue lightning icon).
2. The transfer engine starts and opens your browser automatically!
3. Other devices on your Wi-Fi can now connect via PIN or QR code.

HOW TO STOP:
- Click the "Stop & Exit" button on the File Transfer Fast window.

NOTE:
- Node.js (https://nodejs.org) powers the high-speed transfer engine.
  If not already installed, FileTransferFast.exe will provide a 1-click link.
- Alternatively, you can also run "start-app.bat" anytime.
